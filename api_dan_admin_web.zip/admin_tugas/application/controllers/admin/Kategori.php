<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller {
	
	public function add()
	{
		$this->load->helper('url');
		// print_r($this->input->post());die;
        foreach($this->input->post('checkMenu') as $item){

            $new_data = [
                'id_kategori' => $this->input->post('id_kategori'),
                'id_menu' => $item,
            ];
            
            $this->db->insert('menu_kategori',$new_data);
        }

		$msg = "<div class='alert alert-success' role='alert'>Data kategori berhasil diinput </div>";
		$this->session->set_flashdata('pesan', $msg);
		redirect('admin/Home');
	}

    public function delete($id){
		$this->db->where(array('id_kategori'=>$id));
		$data = $this->db->get('kategori')->row();
		// echo $this->db->last_query();die;

		$this->db->where(array('id_kategori'=>$id));
		$this->db->delete('kategori');
		$msg = "<div class='alert alert-success' role='alert'>Data kategori berhasil dihapus </div>";
		$this->session->set_flashdata('pesan', $msg);
		redirect('admin/Home');
	}

    public function delete_menu_kateg($id){
        $this->db->where(array('id_menu_kategori'=>$id));
		$this->db->delete('menu_kategori');
		$msg = "<div class='alert alert-success' role='alert'>Data kategori Mapping berhasil dihapus </div>";
		$this->session->set_flashdata('pesan', $msg);
		redirect('admin/Home');
    }
}
