<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function index()
	{
		$this->load->helper('url');
        // $data = $this->db->get('menu')->result();
        // var_dump($data);die;
		$this->load->view('admin/login');
	}
}
