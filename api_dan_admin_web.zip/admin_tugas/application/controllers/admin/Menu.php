<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu extends CI_Controller {
	
	public function index()
	{
		$this->load->helper('url');
		$this->load->view('admin/home');
	}

	public function add()
	{
		if ($this->input->method() === 'post') {
			// the user id contain dot, so we must remove it
			$file_name = $this->input->post('nama_menu');
			$config['upload_path']          = FCPATH.'/images/';
			$config['allowed_types']        = 'gif|jpg|jpeg|png';
			$config['file_name']            = $file_name;
			$config['overwrite']            = true;
			$config['max_size']             = 1024; // 1MB
			

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('gambar')) {
				$data['error'] = $this->upload->display_errors();
				$msg = "<div class='alert alert-primary' role='alert'>Data gagal diinput ".$data['error']."</div>";
				$this->session->set_flashdata('pesan', $msg);
			} else {
				$uploaded_data = $this->upload->data();
				// var_dump($this->input->post());die;
				chmod($config['file_name'],0777);
				chown($file_name, "dimas");
				$new_data = [
					'nama_menu' => $this->input->post('nama_menu'),
					'rating' => '0.0',
					'from_rating' => 0,
					'gambar' => '/images/'.$uploaded_data['file_name'],
					'deskripsi' => $this->input->post('deskripsi')
				];
				
				$this->db->insert('menu',$new_data);
				$msg = "<div class='alert alert-success' role='alert'>Data berhasil diinput  </div>";
				$this->session->set_flashdata('pesan', $msg);
				redirect('admin/Home');
			}
		}
	}

	public function delete($id){
		$this->db->where(array('id_menu'=>$id));
		$data = $this->db->get('menu')->row();
		// echo $this->db->last_query();die;

		unlink(FCPATH.$data->gambar);
		$this->db->where(array('id_menu'=>$id));
		$this->db->delete('menu');
		$msg = "<div class='alert alert-success' role='alert'>Data berhasil dihapus </div>";
		$this->session->set_flashdata('pesan', $msg);
		redirect('admin/Home');

	}
}
