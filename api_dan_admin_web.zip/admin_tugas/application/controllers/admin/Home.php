<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	
	public function index()
	{
		$this->load->helper('url');
		$this->load->model('general_model');
		$data = array();
        $data['menu'] = $this->db->get('menu');
        $data['kategori'] = $this->db->get('kategori');
        $data['menu_kateg'] = $this->general_model->getSpesificWhereJoin('*',['menu_kategori','menu','kategori'],['menu_kategori.id_menu=menu.id_menu','menu_kategori.id_kategori=kategori.id_kategori'],['inner','inner'],[]);
		
        // var_dump($data);die;
		$this->load->view('admin/home',$data);
	}
}
