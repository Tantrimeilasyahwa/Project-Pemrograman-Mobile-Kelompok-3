<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class General_model extends CI_Model {

    public function getSpesificWhereJoin($field,$table,$condition,$type_join,$where)
	{	
		$this->db->select($field);
		if(is_array($table)){
			foreach ($table as $key => $value) {
				if($key == 0){
					$this->db->from($table[$key]);
				}else{
					$this->db->join($table[$key],$condition[$key-1],$type_join[$key-1]);
				}
			}
		}
		$this->db->where($where);
		$query = $this->db->get();
		return $query;
	}

	function get_data_table_no_paging($tables, $wheres="", $isOrder = 0, $order_by = ""){
		if ($wheres != '') {
			$this->db->where($wheres);
		}

		if($isOrder){
			$this->db->order_by($order_by); 
		}		
		$return = $this->db->get($tables);
	
		return $return;

	}

}