<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Login - Home</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">    </head>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <style>
        body{
            background-color : #e8e6e6;
        }
        .login-card {
            background-color : #ffff;
            width : 95%;
            height : 400px;
            border-radius : 10px; 
            margin: 2em 2em 2em 2em;
            /* margin-top : 2em; */
            box-shadow: 5px 10px 10px 2px lightgrey;
            /* padding-top : 1.5em; */
        }

        .login-card > h4 {
            padding : 1em 2em 0 2em;
        }

        .row-widget {
            padding : 2em 1em 2em 3em ;
        }
       
        .widget{
            width : 400px;
            border-radius : 5px;
            margin-right : 0.5em;
            color : #fff;
            padding : 0 2em 0 2em;
            background: rgb(22,61,222);
            background: linear-gradient(180deg, rgba(22,61,222,1) 0%, rgba(255,255,255,0.5760504030713849) 100%);
            box-shadow: 5px 10px 10px 2px lightgrey;
        }

        .widget > img {
            width : 70px;
            margin-left : 11em;
        }

        .widget-text {
            font-size : 60px;
        }
        
        

        @media screen and (max-width: 600px) {
            .login-card {
                width : 87%;
                height : 95%;
                padding-right : 1.8em;
            }

            .widget {
                margin-bottom : 1em;
            } 
        }

        .float{
            position:fixed;
            width:60px;
            height:60px;
            bottom:40px;
            right:40px;
            background-color:red;
            color:#FFF;
            border-radius:50px;
            text-align:center;
            box-shadow: 2px 2px 3px #999;
        }

        .my-float{
            margin-top:22px;
        }

        .btn-icon{
            width :15px;
        }
    </style>
    </head>
    <body >
        <div class="root">
            <a data-toggle="modal" data-target="#modal_logout" href="#" class="float">
                <img src="<?=base_url()?>images/icons/logout_white.svg" style="width:40px;margin-top:0.6em;" alt="logout">
            </a>
            <nav class="navbar navbar-expand-lg navbar-light bg-primary">
                <a class="text-light navbar-toggler" href="#">Administrator</a>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                    <a class="text-light navbar-brand" href="#">Administrator</a>
                </div>
            </nav>
            <div>
                <div class="login-card ">
                    <h4><img src = "<?=base_url()?>images/icons/info.svg">Informasi</h4><hr>
                    <?php
                    if($this->session->flashdata('pesan')){
                        echo $this->session->flashdata('pesan');
                    }
                    ?>
                    <div class="row-widget row">
                        <div class="widget  bg-primary">
                            <span class="widget-text"><?=$menu->num_rows()?></span>
                            <img src = "<?=base_url()?>images/icons/list_white.svg" alt="My Happy SVG"/>
                            <div class="row">
                                <div class="col-lg-8">
                                    <p class="widget-text-note">Menu Makanan</p>
                                </div>
                                <div class="col-lg-4">
                                    <button data-toggle="modal" data-target="#modal_menu" class="ml-2 btn-sm btn btn-light btn-block" >Lihat</button>
                                </div>
                            </div>
                        </div>
                        <div class="widget  bg-warning">
                            <span class="widget-text"><?=$kategori->num_rows()?></span>
                            <img src = "<?=base_url()?>images/icons/list_white.svg" alt="My Happy SVG"/>
                            <div class="row">
                                <div class="col-lg-8">
                                    <p class="widget-text-note">Kategori Menu</p>
                                </div>
                                <div class="col-lg-4">
                                    <button data-toggle="modal" data-target="#modal_ketegori" class="ml-2 btn-sm btn btn-light btn-block" >Lihat</button>
                                </div>
                            </div>
                        </div>
                        <div class="widget bg-success">
                            <span class="widget-text"><?=$menu_kateg->num_rows()?></span>
                            <img src = "<?=base_url()?>images/icons/list_white.svg" alt="My Happy SVG"/>
                            <div class="row">
                                <div class="col-lg-8">
                                    <p class="widget-text-note">Kategori Maping</p>
                                </div>
                                <div class="col-lg-4">
                                    <button data-toggle="modal" data-target="#modal_rating" class="ml-2 btn-sm btn btn-light btn-block" >Lihat</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id='modal_menu' tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Menu Makanan</h5>
                    <button onclick = "openForm('#div_form_tambah_menu')"   class="btn btn-success btn-sm"  aria-label="Close">
                        <img class="btn-icon" src="<?=base_url()?>images/icons/add_white.svg" alt=""> Tambah Makanan
                    </button>
                </div>
                <div class="modal-body">
                <div id="div_form_tambah_menu" target="open" style="display:none">
                    <?=form_open_multipart('admin/Menu/add','id="form_tambah_menu" method="POST"')?>
                        <div class="row">
                            <div class="col">
                                <label for="inputNamaMakanan">Nama Makanan</label>
                                <input type="text"  name="nama_menu" class="form-control" placeholder="Nama Makanan">
                            </div>
                            <div class="col">
                                <label for="inputEmail4">Gambar</label>
                                <input type="file" class="form-control" name="gambar" placeholder="File Gambar" accept=".jpg,.jpeg, .png">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="inputEmail4">File</label>
                                <textarea class="form-control" name="deskripsi" nama="deskrpsi" id="mytextarea" cols="30" rows="10"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer" >
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
                <hr>
                <div id="table_menu">
                    <table class="table table-striped table-bordered" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Gambar</th>
                                <th>Deskripsi</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach($menu->result() as $listmenu){
                                ?>
                            <div class="row bg-light" style="display:none" id="full_<?=$no?>">
                                <div class="container">
                                    <h3><?=$listmenu->nama_menu?></h3>
                                    <img class="img-rounded mb-3" src="<?=base_url().$listmenu->gambar?>" alt="" style="width:300px">
                                    <p><?=$listmenu->deskripsi?></p>
                                </div>
                            </div>
                            <tr>
                                <td><?=$no?></td>
                                <td><?=$listmenu->nama_menu?></td>
                                <td> <img src="<?=base_url().$listmenu->gambar?>" style="width:100px"></td> 
                                <td id="desc_<?=$no?>"><?=$listmenu->deskripsi?></td>
                                <td class="text-center">
                                    <a href="<?=base_url('/admin/Menu/delete/'.$listmenu->id_menu)?>">
                                        <button class="btn btn-sm btn-danger">Hapus</button>
                                    </a>
                                </td>
                            </tr>
                            

                            <?php
                                $no++;
                                } 
                            ?>
                        </tfoot>
                    </table>
                </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id='modal_ketegori' tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Menu Kategori Makanan</h5>
                    <!-- <button class="btn btn-success btn-sm" type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <img class="btn-icon" src="<?=base_url()?>images/icons/add_white.svg" alt=""> Tambah Menu
                    </button> -->
                </div>
                <div class="modal-body">
                <?php
                $no_kategori = 1 ;
                foreach($kategori->result(  ) as $kategoris){
                ?>
                <div style="display:none" id="fullkate<?=$kategoris->id_kategori?>" class="container bg-light">
                    <?=form_open_multipart('admin/Kategori/add','id="form_tambah_kategori" method="POST"')?>
                    <table class="table table-striped table-bordered" style="width:100%">
                        <input type="hidden" name="id_kategori" value="<?=$kategoris->id_kategori?>">              
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Menu</th>
                                    <th>Gambar</th>
                                    <th>Pilih</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no_menu = 1 ;
                                foreach($menu->result() as $menus){  
                                ?>
                                <tr>
                                    <td><?=$no_menu?></td>
                                    <td><?=$menus->nama_menu?></td>
                                    <td><?=$menus->nama_menu?></td>
                                    <td><input type="checkbox"  name="checkMenu[]" value="<?=$menus->id_menu?>"></td>
                                </tr>
                                <?php $no_menu++;} ?>
                            </tbody>
                        </table>
                        <div class="modal-footer" >
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            <?php } ?>
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Deskripsi</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no_kategori = 1 ;
                        foreach($kategori->result() as $listkategori){
                        ?>
                        
                        <tr>
                            <td><?=$no_kategori?></td>
                            <td><?=$listkategori->nama_kategori?></td>
                            <td><?=$listkategori->deskripsi?></td>
                            <td class="text-center">
                                <!-- <a href="<?=base_url('admin/Kategori/delete/'.$listkategori->id_kategori)?>"> -->
                                    <button onclick="javascript:$('#fullkate<?=$listkategori->id_kategori?>').show()" class="btn btn-info btn-sm">Detail</button>
                                <!-- </a> -->
                            </td>
                        </tr>
                        <?php 
                            $no_kategori++;
                        } 
                        ?>
                    </tfoot>
                </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id='modal_rating' tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Rating Makanan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Menu</th>
                            <th>Nama Kategori</th>
                            <th>Gambar</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $no_kateg = 1;
                    foreach($menu_kateg->result() as $kate){                    
                    ?>
                        <tr>
                            <td><?=$no_kateg?></td>
                            <td><?=$kate->nama_menu?></td>
                            <td><?=$kate->nama_kategori?></td>
                            <td><img src="<?=base_url($kate->gambar)?>" style="width:100px"></td> 
                            <td>
                                <a href="<?=base_url('admin/Kategori/delete_menu_kateg/'.$kate->id_menu_kategori)?>">
                                    <button type="button" class="btn btn-sm btn-danger">Hapus</button>
                                </a>
                            </td>
                        </tr>
                    <?php $no_kateg++;} ?>
                    </tfoot>
                </table>
                </div>
                <div class="modal-footer">
                    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id='modal_logout' tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Rating Makanan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Apakah benar anda ingin logout? dengan ini session akan hilang!</p>
                </div>
                <div class="modal-footer">
                    <a href="<?=base_url('admin/Login')?>">
                        <button type="button" class="btn btn-danger">Logout</button>
                    </a>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
                </div>
            </div>
        </div>
    </body>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap4.min.js"></script>
    <script src='https://cdn.tiny.cloud/1/no-api-key/tinymce/4/tinymce.min.js'></script>
    <script src="<?=base_url()?>assets/js/action.js"></script>

    <script>
       $(document).ready(function () {
            $('table').DataTable();
        });

        tinymce.init({
            selector: '#mytextarea'
        });

        const openForm = (id) => {
            $(id).attr('target',function(index,currentvalue){
                if(currentvalue == 'open'){
                    $(id).slideDown('100');
                    $(id).attr('target','close');
                }else{
                    $(id).slideUp('100');
                    $(id).attr('target','open');
                }
            })
            $(id).addClass('active');
        }

        const getFull = (idTd,idTable,type) => {
            if(type == 'close'){
                $(idTd).show(100);
                $(idTable).hide(100);
            }else{
                $(idTd).hide(100);
                $(idTable).show(100);
            }
        }
    </script>
</html>